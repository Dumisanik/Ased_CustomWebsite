/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


jQuery(MenuListMouseOver);      //Instead of using JQuery(), you can use the dollar sign :-) $()

function MenuListMouseOver(thisObject){
    jQuery("div.EntireMenu li").css("background","white");  
    alert("Mouse Over");
}


$("div.EntireMenu li").mouseover(MenuListMouseOver());




$("li").mouseout(function(){
    alert("Mouse Out");
});